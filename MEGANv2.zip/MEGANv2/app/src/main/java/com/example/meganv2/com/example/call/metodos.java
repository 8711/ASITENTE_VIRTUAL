package com.example.meganv2.com.example.call;

import com.example.meganv2.MainActivity;

public class metodos
{
    MainActivity objeto = new MainActivity();

    public void PrepararAccionIntents(  )
    {

    int numero = ( int ) ( Math.random()* 10 -1);
        switch ( numero )
        {
            case 0:
                objeto.paginaWeb();
                break;
            case 1:
                objeto.AbrirGaleria();
                break;
            case 2:
                objeto.ExploradorArchs();
                break;
            case 4:
                objeto.CamaraFotos();
                break;
            case 5:
                objeto.GoogleMaps();
                break;
            case 6:
                objeto.EnviarCorreo();
                break;
            case 7:
                objeto.HacerLlamada();
                break;
            default:
                break;

        }
    }
}
